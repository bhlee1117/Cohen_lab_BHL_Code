
HiLo_ImageJ_result_image.tiff was produced the by the HiLo ImageJ plugin using the "uniform_image" and "structured_speckle_image" with settings:


Camera gain: 0.15
Readout noise: 1.64
Magnification: 40
Pixel size: 22.2
Illumination wavelength: 488
Detection wavelength: 520
Illumination NA: 0.30
Detection NA: 0.40

Depth field multiplier: 2.0
HiLo weighting: 3.0



The image shows GFP-labeled neurons in a mouse cortex slice and comes from the Mertz lab home page: http://biomicroscopy.bu.edu/resources/4

These images can be used to validate the output of the MATLAB code with respect to that produced by ImageJ.