% Loads the part of a movie as specified in a loaded TNT settings file
movie = read_tiff(filename_movie, false,  firstFrame_lastFrame);