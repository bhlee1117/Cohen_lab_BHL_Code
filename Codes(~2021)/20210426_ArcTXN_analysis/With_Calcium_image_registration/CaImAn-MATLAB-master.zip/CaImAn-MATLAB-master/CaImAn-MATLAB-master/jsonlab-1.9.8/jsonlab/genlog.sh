#!/bin/sh

git log --date=short --pretty='format: %cd [%h] %s'
