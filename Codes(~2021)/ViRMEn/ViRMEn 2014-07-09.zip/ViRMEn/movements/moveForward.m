function velocity = moveForward(vr) %#ok<INUSD>

velocity = [0 10 0 0];