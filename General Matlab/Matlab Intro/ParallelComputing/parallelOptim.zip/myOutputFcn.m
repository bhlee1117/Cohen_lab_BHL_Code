function stop = myOutputFcn(varargin)

% Copyright 2006 The MathWorks, Inc.


if nargin == 0
  % return function handle to be used as an output function
  
  stop = @(x, optimValues, state) myOutputFcn(x, optimValues, state);

else
  % stores the intermediate optimization results

  stop = false;

  storeResultsFcn(varargin{:});

end


%--------------------------------------------------------------------------
function storeResultsFcn(x, optimValues, state)
% Stores intermediate optimization results
% Use this as a custom output function


switch state
  case 'init'
    setappdata(0, 'optim_xSaved', []);
    
  case 'iter'
    setappdata(0, 'optim_xSaved', [getappdata(0, 'optim_xSaved'), x]);
        
end