%% Cell Tower Optimization Problem
% This demo illustrates how you would set up and solve an optimization
% problem (constrained non-linear minimization) in parallel using the
% built-in parallel support in the Optimization Toolbox for the use of 
% Parallel Computing Toolbox.
%
% The problem is to determine the locations of # cell towers, each having
% various coverage radius, so that there is maximum coverage, or minimum
% overlap. It is a constrained optimization problem because the cell towers
% are constrained to lie within a boundary. It is a non-linear optimization
% problem because of the non-linear objective function (overlap area as a
% function of # cell tower locations).
%

%% Define parameters

towers = 30;  % number of towers
side = 15;    % dimension of piece of land (one side)
seed = 5;     % seed for random initial condition (not relavent to optimization

%% Define initial conditions
% |celltowersetup.m| sets up the initial conditions:
%
%  R  : radius of cell tower coverage
%  xL : 0       % for plotting
%  xU : side    % for plotting
%  yL : 0       % for plotting
%  yU : side    % for plotting
%  lb : lower bound values for x, y (based on the radius)
%  ub : upper bound values for x, y (based on the radius)

[R,xL,xU,yL,yU,lb,ub,x0] = celltowersetup(towers,side,seed);


%% Run the following optimization

tic
[x,fval,exitflag,output] = myOptim(x0,lb,ub,R);
toc

%% Summary visualization
% If you added the custom output function |myOutputFcn| in Optim GUI, you
% can get a summary visualization:

plotOptimSummary(output,R,xL,xU,yL,yU);

