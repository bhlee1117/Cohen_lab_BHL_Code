function f = plotFcn(varargin)

% plotFcn
%
% Plotting function for celltower problem.
% Plots the locations of cell towers.
%

% Copyright 2003 The MathWorks, Inc.

if nargin == 0
  % return function handle to be used as a plotting function

  f = @(x,itervals,flag) plotFcn(x,itervals,flag);
  
else
  % plots cell tower locations
  
  f = myplotcircles(varargin{:});
  
end


%--------------------------------------------------------------------------
function stop = myplotcircles(x,itervals,flag, varargin)
% Plotting function for displaying the cell tower locations

if nargin > 3
  R  = varargin{1};
  xL = varargin{2};
  xU = varargin{3};
  yL = varargin{4};
  yU = varargin{5};
else
  % Get constants from the base workspace
  R  = evalin('base', 'R');
  xL = evalin('base', 'xL');
  xU = evalin('base', 'xU');
  yL = evalin('base', 'yL');
  yU = evalin('base', 'yU');
end

stop = false;

% pts = reshape(x,2,length(x)/2);
% X = pts(1,:);
% Y = pts(2,:);
X = x(1:2:end, :);
Y = x(2:2:end, :);
N = length(R);

if isnumeric(itervals)
  iter = itervals;
else
  iter = itervals.iteration;
end

switch flag
  case {'iter', ''}
    t = 0:.1:2*pi+0.1;

    cla;
    for i = 1:N
      plot(R(i)*cos(t) + X(i),R(i)*sin(t) + Y(i),'linewidth',2)
      text(X(i),Y(i),num2str(i))
      hold on
    end

    plot([xL;xU;xU;xL;xL],[yL;yL;yU;yU;yL],'r--','linewidth',2);
    axis([xL-1, xU+1, yL-1, yU+1]);
    axis square;
    
    title(sprintf('Iteration: %d', iter));
    pause(.1);
end