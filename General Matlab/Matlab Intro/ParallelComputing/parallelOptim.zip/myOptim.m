function [x,fval,exitflag,output,lambda,grad,hessian] = myOptim(x0,lb,ub,R)
% This is an auto generated M-file to do optimization with the Optimization Toolbox.
% Optimization Toolbox is required to run this M-file.

% Copyright 2006 The MathWorks, Inc.

% Start with the default options
options = optimset;

% Modify options setting
options = optimset(options,'Display' ,'iter');
options = optimset(options,'TolFun' ,0.0001);
options = optimset(options,'OutputFcn' ,{ @myOutputFcn });
% options = optimset(options,'PlotFcns' ,{  @optimplotfval @(x,itervals,flag) plotFcn(x,itervals,flag) });
options = optimset(options,'LargeScale' ,'off');
options = optimset(options,'UseParallel','always');
options = optimset(options, 'Algorithm', 'active-set');
[x,fval,exitflag,output,lambda,grad,hessian] = ...
fmincon(@(x) objFcn(x,R),x0,[],[],[],[],lb,ub,[],options);
