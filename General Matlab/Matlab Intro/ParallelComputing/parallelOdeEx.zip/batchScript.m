%% Submitting Serial and Parallel Scripts
% This schedules a parameter sweep study of a 2nd order ODE system.
%
%   m*X'' + b*X' + k*X = 0
%
% This example will schedule both a serial (parfor w/out a matlabpool) and
% parallel (parfor w/a matlabpool) version. 
%
% The batch command sends your serial script to run on one worker in your
% cluster. batch with the 'matlabpool' option sends scripts containing
% parfor to run on workers via a MATLAB pool.  In this process, one worker
% behaves like a MATLAB client process that facilitates the distribution of
% the job amongst the workers in the pool and runs the serial portion of
% the script. 
%
% All of the variables in your client workspace (e.g. the MATLAB process
% you are submitting from) are sent to the worker by default. You can
% alternatively pass a subset of these variables by defining the Workspace
% argument and passing the desired variables in a structure. 
%
% After your job has finished, you can use the load command to retrieve the
% results from the worker-workspace back into your client-workspace.  In
% this and all other scheduling examples, we use a wait to ensure the job
% is done before we load back in worker-workspace. This is optional, but
% you can not load the data from a task or job until that task or job is
% finished. So, we use wait to block the MATLAB command line until that
% occurs. 
%
%
% Copyright 2009 The MathWorks, Inc.

%% Submitting the job

job = batch('paramSweep');
% job = batch('paramSweep','FileDependencies',{'odesystem.m'});

%% Check the job's state

job.State

%% Waiting until the job is done to load data back in

wait(job);
load(job);

%% Visualize using output data from workers

figure;
surf(bVals, kVals, peakVals);
xlabel('Damping'); ylabel('Stiffness'); zlabel('Peak Displacement');
view(50, 30)

%% Submitting a Script that Uses Parfor

% job = batch('paramSweep','matlabpool',2); % Total of 3 Workers
job = batch('paramSweep','matlabpool',2,'FileDependencies',{'odesystem.m'});

%% Waiting until the job is done to load data back in

wait(job);
load(job);

%% Visualize using output data from workers

figure;
surf(bVals, kVals, peakVals);
xlabel('Damping'); ylabel('Stiffness'); zlabel('Peak Displacement');
view(50, 30)
