%% Scheduling different solvers on the same ODE system
% In this script, we are looking at spring damper system and comparing the results from the ODE45
% and ODE23 solvers with the analytical solution.
% 
% In this version, we are scheduling a task parallel job with multiple
% tasks. Each task evaluates a different MATLAB function. The createTask
% function in the below example is passed the job, the function to be run
% in the form of a function handle, the number of output arguments of the
% function, and the input arguments to the function in the form of a cell
% array. 
% 
% If not given a configuration, findResource uses the scheduler found in
% the default configuration.   
%
% Copyright 2009 The MathWorks, Inc.

%% Setting initial conditions
m = 5;  % mass
b = 0.5;  % damping value
k = 1.5;  % stiffness value
totalTime = 25; % total time of simulation

%% Find resource/scheduler
sched = findResource();

%% Create job and tasks 
job = createJob(sched);
set(job,'FileDependencies',{'springDampSolver45.m', ...
                            'springDampSolver23.m', ...
                            'springDampSolverAna.m'})

% [T1,Y1] = springDampSolver45(m,k,b,totalTime); [T2,Y2] =
% springDampSolver23(m,k,b,totalTime); [T3,Y3] =
% springDampSolverAna(m,k,b,totalTime);

task1 = createTask(job,@springDampSolver45,2,{m,k,b,totalTime});
task2 = createTask(job,@springDampSolver23,2,{m,k,b,totalTime});
task3 = createTask(job,@springDampSolverAna,2,{m,k,b,totalTime});

%% Submitting job

submit(job)
wait(job) % optional, only load when job is finished

%% Plotting results to compare

results = getAllOutputArguments(job);
comparePlot(results{1,1},results{2,1},results{3,1},...
            results{1,2},results{2,2},results{3,2});
        
%% Destroy job when finished

destroy(job)