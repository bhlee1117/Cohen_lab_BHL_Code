function comparePlot(T1,T2,T3,Y1,Y2,Y3)
%COMPAREPLOT 

ax(1) = subplot(2,1,1);
plot(T1,Y1(:,1),'r+',T2,Y2(:,1),'b+',T3,Y3(:,1),'k')
ylabel('Position')
xlabel('Time')
legend('ODE45','ODE23',2, 'Location','NorthEast');

ax(2) = subplot(2,1,2);
plot(T1,Y1(:,2),'r+',T2,Y2(:,2),'b+',T3,Y3(:,2),'k')
ylabel('Velocity')
xlabel('Time')
legend('ODE45','ODE23',2, 'Location','NorthEast');

linkaxes(ax,'x')

end

