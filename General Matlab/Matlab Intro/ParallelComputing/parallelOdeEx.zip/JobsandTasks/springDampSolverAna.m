function [T,Y] = springDampSolverAna(m1,k1,b1,totalTime)

param.m = m1;
param.b = b1;
param.k = k1;

%% Solving Symbolically in MATLAB
% You can solve equations symbolically using the Symbolic Math Toolbox. In
% order to do that, you need to first define your symbolic variables.

syms x m k b

%%
% Use |dsolve| to solve the differential equation. 

f0 = dsolve('m*D2x +  b*Dx + k*x = 0' , 'Dx(0) = 1', 'x(0) = 0');

f0 = simplify(f0);


%%
% The solution can be evaluated at specific values using the |subs|
% function.

f2 = subs(f0, {m b k}, {param.m param.b param.k});
f2d = diff(f2); % calculating the derivative

% We can generate a function handle from our symbolic solution.

springDamp = matlabFunction(f2,f2d);

T = (0:0.1:totalTime)';  % Define a vector to evaulate on

[Y(:,1), Y(:,2)] = springDamp(T);


