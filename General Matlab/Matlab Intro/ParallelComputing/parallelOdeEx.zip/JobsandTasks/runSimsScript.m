%% Trying different solvers on the same ODE system
% This example looks at the spring damper system and comparing the results
% from the ODE45 and ODE23 solvers with the analytical solution. This is
% the serial and non-scheduled version.
%
% Copyright 2009 The MathWorks, Inc.


%% Initial conditions
m = 5;  % mass
b = 0.5;  % damping value
k = 1.5;  % stiffness value
totalTime = 25; % total time of simulation

%% Using ODE45

[T1,Y1] = springDampSolver45(m,k,b,totalTime);

%% Using ODE23

[T2,Y2] = springDampSolver23(m,k,b,totalTime);

%% Calculating analytical solution

[T3,Y3] = springDampSolverAna(m,k,b,totalTime);

%% Plotting results to compare

comparePlot(T1,T2,T3,Y1,Y2,Y3)

