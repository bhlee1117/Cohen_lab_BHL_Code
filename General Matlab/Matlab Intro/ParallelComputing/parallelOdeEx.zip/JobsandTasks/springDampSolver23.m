function [T,Y] = springDampSolver23(m,k,b,totalTime)

%% Parameter Sweep of ODEs
% This is a parameter sweep study of a 2nd order ODE system.
%
%   m*X'' + b*X' + k*X = 0
%
% We solve the ODE for a time span of 0 to 25 seconds, with initial
% conditions X(0) = 0 and X'(0) = 1. We sweep the parameters "b" and "k"
% and record the peak values of X for each condition. At the end, we plot a
% surface of the results.

% Copyright 2009 The MathWorks, Inc.

%% Solve ODE
 
[T,Y] = ode23(@(t,y) odesystem(y, m, b, k), ...
    [0, totalTime], ...  % simulate for totalTime seconds
    [0, 1]) ;      % initial conditions
 

function dy = odesystem(y, m, b, k)
% 2nd-order ODE
%
%   m*X'' + b*X' + k*X = 0
%
% --> system of 1st-order ODEs
%
%   y  = X'
%   y' = -1/m * (k*y + b*y')

% Copyright 2009 The MathWorks, Inc.

dy(1) = y(2);
dy(2) = -1/m * (k * y(1) + b * y(2));

dy = dy(:); % convert to column vector