function [a,b] = testFunc
parfor i = 1:10
    a(i) = rand;
    b(i) = mynewFunc(a(i));
end
end

function b = mynewFunc(a)
b = 10;

for i = 1:10
break
end
end

