Energy Forecast Demo

* This demo uses functions from Curve Fitting Toolbox and Statistics Toolbox
* Run and publish "MainAnalysis.m"

* GUI: ForecastGUI.m

Copyright 2009 The MathWorks, Inc.