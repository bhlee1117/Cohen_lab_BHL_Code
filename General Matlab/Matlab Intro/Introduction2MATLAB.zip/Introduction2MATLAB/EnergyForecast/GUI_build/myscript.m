%% Import
data = importfile2('2006Data.xlsm')

%% Select Months to Plot
months = [1 7];

idx = ismember(data.Month, months);

thisHour = data.Hour(idx);
thisTemp = data.Temperature(idx);
thisPower = data.Power(idx);

%% Plot Data Points
plot3(thisHour, thisTemp, thisPower, '.');

%% Create Mathematical Model
model = createSurfaceFit2(thisHour, thisTemp, thisPower)

%% Plot Model
plot(model, 'Parent', gca)
