function y = myfunc(x)

% Copyright 2007 The MathWorks, Inc.


y = sin(2*x.^2+3*x+4);