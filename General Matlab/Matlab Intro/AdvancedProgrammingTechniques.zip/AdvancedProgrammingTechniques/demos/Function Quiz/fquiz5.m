function y = fquiz5(x)
% Function Quiz 5
% Copyright 2007 The MathWorks, Inc.

%% What kind of function is MAKELINE?
a = 3;
b = 5;
y = makeline(x);
 
  function y = makeline(x)
    % Function Quiz 5
    % MAKELINE  Make a line
    y = a*x + b;
  end

end


