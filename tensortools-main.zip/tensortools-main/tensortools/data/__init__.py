"""Routines to create data."""

from .random_tensor import randn_ktensor, rand_ktensor, randexp_ktensor
