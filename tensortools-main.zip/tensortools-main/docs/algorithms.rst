.. -*- rst -*-

Algorithms
==========

.. currentmodule:: tensortools


.. autosummary::
   :toctree: algorithms

   cp_als

   ncp_bcd

   ncp_hals

   mcp_als
