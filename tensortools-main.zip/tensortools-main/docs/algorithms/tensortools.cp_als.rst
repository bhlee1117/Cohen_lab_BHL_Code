Unconstrained CP Tensor Decomposition by Alternating Least Squares (ALS)
========================================================================

.. currentmodule:: tensortools

.. autofunction:: cp_als