Nonnegative CP Tensor Decomposition by Hierarchical Alternating Least Squares (HALS)
====================================================================================

.. currentmodule:: tensortools

.. autofunction:: ncp_hals