Nonnegative CP Tensor Decomposition by Block Coordinate Descent (BCD)
======================================================================

.. currentmodule:: tensortools

.. autofunction:: ncp_bcd