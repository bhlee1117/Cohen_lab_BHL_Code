### `examples/_tests/`

This folder holds some informal tests / sanity checks that I use to spot check the code. The scripts are not well-documented, but they might still be of use to someone.
